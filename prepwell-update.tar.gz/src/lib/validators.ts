import { z } from "zod";

// ─── Auth ─────────────────────────────────────────

export const registerSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  classLevel: z.enum(["SS1", "SS2", "SS3"]),
  track: z.enum(["SCIENCE", "ARTS", "COMMERCIAL"]),
  state: z.string().optional(),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const phoneOtpSchema = z.object({
  phone: z.string().regex(/^(\+234|0)[789]\d{9}$/, "Invalid Nigerian phone number"),
});

export const verifyOtpSchema = z.object({
  phone: z.string(),
  otp: z.string().length(6, "OTP must be 6 digits"),
});

// ─── Assessment ───────────────────────────────────

export const generateQuizSchema = z.object({
  subjectId: z.string(),
  topicIds: z.array(z.string()).optional(),
  count: z.number().int().min(5).max(60).default(10),
  difficulty: z.enum(["BASIC", "INTERMEDIATE", "ADVANCED"]).optional(),
  examType: z.enum(["WAEC", "JAMB", "NECO", "CUSTOM"]).optional(),
});

export const submitAssessmentSchema = z.object({
  attemptId: z.string(),
  answers: z.array(
    z.object({
      questionId: z.string(),
      selectedAnswer: z.string().nullable(),
      timeSpentSeconds: z.number().int().min(0),
      flaggedForReview: z.boolean().optional(),
    })
  ),
});

export const mockExamSchema = z.object({
  examType: z.enum(["WAEC", "JAMB", "NECO"]),
  subjectId: z.string().optional(), // For WAEC/NECO single subject
  jambSubjectIds: z.array(z.string()).length(3).optional(), // For JAMB (3 + English)
});

// ─── Questions (Admin) ────────────────────────────

export const createQuestionSchema = z.object({
  subjectId: z.string(),
  topicId: z.string().optional(),
  examType: z.enum(["WAEC", "JAMB", "NECO", "CUSTOM"]),
  examYear: z.number().int().min(1990).max(2030).optional(),
  questionNumber: z.number().int().optional(),
  questionText: z.string().min(10),
  questionImageUrl: z.string().url().optional(),
  questionType: z.enum(["OBJECTIVE", "THEORY", "FILL_IN_BLANK"]).default("OBJECTIVE"),
  options: z
    .record(z.string(), z.string())
    .refine((opts) => Object.keys(opts).length >= 4, "At least 4 options required")
    .optional(),
  correctAnswer: z.string().min(1),
  explanation: z.string().min(10),
  explanationImageUrl: z.string().url().optional(),
  difficulty: z.enum(["BASIC", "INTERMEDIATE", "ADVANCED"]).default("INTERMEDIATE"),
  marks: z.number().int().min(1).default(1),
  timeEstimateSeconds: z.number().int().min(10).default(90),
});

// ─── Bulk Import (Admin) ─────────────────────────

export const bulkImportQuestionSchema = z.object({
  subjectCode: z.string().min(2),
  topicSlug: z.string().optional(),
  examType: z.enum(["WAEC", "JAMB", "NECO", "CUSTOM"]),
  examYear: z.number().int().min(1990).max(2030).optional(),
  questionNumber: z.number().int().optional(),
  questionText: z.string().min(5),
  questionImageUrl: z.string().url().optional(),
  questionType: z.enum(["OBJECTIVE", "THEORY", "FILL_IN_BLANK"]).default("OBJECTIVE"),
  options: z
    .record(z.string(), z.string())
    .refine((opts) => Object.keys(opts).length >= 4, "At least 4 options required")
    .optional(),
  correctAnswer: z.string().min(1),
  explanation: z.string().min(5),
  explanationImageUrl: z.string().url().optional(),
  difficulty: z.enum(["BASIC", "INTERMEDIATE", "ADVANCED"]).default("INTERMEDIATE"),
  marks: z.number().int().min(1).default(1),
  timeEstimateSeconds: z.number().int().min(10).default(90),
});

export const bulkImportSchema = z.object({
  questions: z.array(bulkImportQuestionSchema).min(1).max(500),
  skipDuplicates: z.boolean().default(true),
});

// ─── Study Plan ───────────────────────────────────

export const generateStudyPlanSchema = z.object({
  targetExam: z.enum(["WAEC", "JAMB", "NECO"]),
  targetDate: z.string().datetime(),
  subjectIds: z.array(z.string()).min(1),
  dailyStudyHours: z.number().min(0.5).max(12).default(2),
});

// ─── Progress ─────────────────────────────────────

export const updateProgressSchema = z.object({
  subjectId: z.string(),
  topicId: z.string().optional(),
  lessonId: z.string().optional(),
  status: z.enum(["NOT_STARTED", "IN_PROGRESS", "COMPLETED"]),
  timeSpentMinutes: z.number().int().min(0).optional(),
});

// Type exports
export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type GenerateQuizInput = z.infer<typeof generateQuizSchema>;
export type SubmitAssessmentInput = z.infer<typeof submitAssessmentSchema>;
export type MockExamInput = z.infer<typeof mockExamSchema>;
export type CreateQuestionInput = z.infer<typeof createQuestionSchema>;
export type GenerateStudyPlanInput = z.infer<typeof generateStudyPlanSchema>;
export type BulkImportQuestionInput = z.infer<typeof bulkImportQuestionSchema>;
export type BulkImportInput = z.infer<typeof bulkImportSchema>;
